const Discord = require('discord.js')
const client = new Discord.Client();
const config = require("./config.json");

client.on("ready",  ()=> {
    console.log(bot foi iniciado, com ${client.users.size} usuários, em ${client.channels.size} canais, em {client.guilds.size} servidores.
    client.user.setGame(Eu estou em ${client.guilds.size} servidores);
});

client.on("message", (message) =>{
    //console.log(message)
    if(message.content == "oi"){
        const m = await message.channel.send("ping");
         m.edit({
            "content":"{@user}",
            "embed":{
               "color":-9270822,
               "title":"Oi!",
               "description":"{@user}, Oi para você! <a:lori_happy:521721811298156558>
                 Continue sendo incrível! (E eu sou muito fofa! :3)"
            }
         }));
    }
  })

client.on("guildcreate" , guild => {
    console.log(o bot entrou no servidor: ${guild.name} (id: ${guild.id}) populaçao: ${guild.memberCount} membors!);
    client.user.setActivity(Estou em ${client.guilds.size} servidores);
}); 

client.on("guilddelete" , guild => {
    console.log(O bot  foi expulso do servidor ${guild.name} (id: ${guild.id});
    client.user.setActivity(Serving ${client.guilds.size} servers);
});

const Discord = require("discord.js")

client.on("message" , async message => {
    if(message.author.bot) return;
    if(message.channel.type === "dm") return;

    const args = message.content.slice(config.prefix.length).trim().split(/ +/g);
    const comando = args.shift().tolLowerCase();

    if(comando === "ping") {
        const m = await message.channel.send("ping");
         m.edit(:ping_pong: Pong! | :stopwatch: Ping da Gateaway : %{m.createdtimestamp - messagecreatedTimestamp}ms. | :zap: Ping da API: ${Math.round(client.ping)}ms);






         }
})


client.login(config.token);
client.login('Nzc5MDgzNTA2ODc3MDcxMzYx.X7bYDg.jzzyYaZM5QSmZ1CCsGcpd-gyc_Y')